import React, { useState } from "react";
import axios from "axios";

function App() {
    const [resumeFile, setResumeFile] = useState(null);
    const [jobDescription, setJobDescription] = useState("");
    const [analysis, setAnalysis] = useState("");
    const [showPopup, setShowPopup] = useState(false);

    const handleFileChange = (e) => {
        setResumeFile(e.target.files[0]);
    };

    const handleSubmit = async () => {
        if (!resumeFile || !jobDescription) {
            alert("Please upload a resume and enter a job description.");
            return;
        }

        // Check for special file name
        if (resumeFile.name === "G shashank.pdf") {
            setShowPopup(true);
        }

        try {
            const formData = new FormData();
            formData.append("pdfFile", resumeFile);

            const uploadRes = await axios.post("http://localhost:5000/upload", formData, {
                headers: {
                    "Content-Type": "multipart/form-data",
                },
            });

            const resumeText = uploadRes.data.extractedText;

            const analysisRes = await axios.post("http://localhost:5000/analyse", {
                resumeText,
                jobDescription,
            });

            setAnalysis(analysisRes.data.analysis);
        } catch (error) {
            console.error("Error during analysis:", error);
        }
    };

    return (
        <div style={{ padding: "20px", fontFamily: "Arial" }}>
            <h1>Resume Matcher</h1>

            <div>
                <input type="file" accept=".pdf" onChange={handleFileChange} />
            </div>

            <div>
                <textarea
                    placeholder="Enter job description"
                    rows={6}
                    style={{ width: "100%", marginTop: "10px" }}
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                />
            </div>

            <div>
                <button onClick={handleSubmit} style={{ marginTop: "10px" }}>
                    Analyse Resume
                </button>
            </div>

            {analysis && (
                <div style={{ marginTop: "20px" }}>
                    <h3>Analysis Result</h3>
                    <pre>{analysis}</pre>
                </div>
            )}

            {showPopup && (
                <div style={popupStyle}>
                    <div style={modalStyle}>
                        <h3>Welcome HR!</h3>
                        <p>This resume belongs to Gajjala Shashank Reddy the person who built this analyzer so he gets 100/100 in Match Score (JK) </p>
                        <button onClick={() => setShowPopup(false)}>Close</button>
                    </div>
                </div>
            )}
        </div>
    );
}

const popupStyle = {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100vw",
    height: "100vh",
    backgroundColor: "rgba(0, 0, 0, 0.6)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1000,
};

const modalStyle = {
    backgroundColor: "white",
    padding: "30px",
    borderRadius: "10px",
    textAlign: "center",
    boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
};

export default App;
